/*
Write a program to print first 5 values which are divisible by 2, 3, and 5.
*/

class Prog19 {
    public static void main(String[] args) {
        for (int i = 1;i <= 5;i++) {
            System.out.println(30 * i);
        }
    }
}