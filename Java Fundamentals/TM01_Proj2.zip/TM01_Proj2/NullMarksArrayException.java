package com.mile1.exception;

public class NullMarksArrayException extends Exception {

    public NullMarksArrayException() {
        super();
    }

    public String toString() {
        return "NullMarksArrayException occurred";
    }
}