Wipro TalentNext PBL

Topics Covered

Hands-on Assignments for Assert methods and annotations, Before, After, Test, assertEquals, assertTrue, assertFalse



No. 	Hands-on Assignment 	Topics Covered 	Status

1 	

 Create a class Employee and implement the below method in the class.
Write Junit testcases to test the below given method:

public String findName(ArrayList employees,String name){
  String result="";
  if(employees.contains(name)){
   result="FOUND";
  }else{
   result="NOT FOUND";
  }
  return result;
 }

	Junit Introduction Using assertEquals method 	

2 	

 i) Create the following class and implement the method to check whether given string is a palindrome and return the result,
Class Name : MyUnit
Method : palindromeCheck(String):boolean

(Hint: If the reversed string is equal to the actual string is palindrome string. Ex: madam, mom, dad, malayalam )
ii) Create a Junit test class to test the above class.

	Junit Introduction Using assertTrue/ assertFalse method 