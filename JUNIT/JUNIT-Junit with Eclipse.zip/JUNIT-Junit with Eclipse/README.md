Wipro TalentNext PBL

Topics Covered

Hands-on Assignments for Junit with Eclipse



No. 	Hands-on Assignment 	Topics Covered 	Status

1 	

 i)  Create the following class and implement the method to concatenate two strings and return the result,
Class Name: MyUnit
Method: stringConcat(String,String):String
Create a Junit test class to test the above class.

	Junit Introduction Using assertEquals method 