package com.w3epic.wiprotraining.assignment1;

public class Calc {
	public int add(int v1, int v2) {
		return v1 + v2;
	}
	
	public int sub(int v1, int v2) {
		return v1 - v2;
	}
}
