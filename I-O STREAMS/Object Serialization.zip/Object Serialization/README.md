Wipro TalentNext PBL

Topics Covered: Object Serialization & Deserialization


No. 	Hands-on Assignment 	Topics Covered 	Status

1 	

 Create an employee object having properties name, date of birth, department, designation and salary. Let the employee class have appropriate getter/setters methods for accessing these properties. Initialize these properties through the setter methods. Store this object into a file "OutObject.txt". Read the same object from the same file and display its properties through getter methods.

	Object Serialization & Deserialization 	