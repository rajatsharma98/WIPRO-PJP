Wipro TalentNext PBL

Topics Covered Hands-on Assignments for Set


No. 	Hands-on Assignment 	Topics Covered 	Status

1 	

 Develop a java class with a instance variable Country  HashSet (H1)  add a method saveCountryNames(String CountryName) , the method should add the passed country to a HashSet (H1) and return the added HashSet(H1).
Develop a method getCountry(String CountryName) which iterates through the HashSet and returns the country if exist else return null. 
NOTE: You can test the methods using a main method.

	Set HashSet 	

2 	

 Write a program to store a group of employee names into a HashSet, retrieve the elements one by one using an Iterator.

	Set HashSet 	

3 	

 Create Collection called TreeSet which is capable of storing String objects. The Collection should have the following capabilities
a)Reverse the elements of the Collection 
b)Iterate the elements of the TreeSet 
c) Checked if a particular element exists or not

	Set TreeSet 	

4 	

 Implement the assignment 1 using TreeSet

	Set TreeSet 	