package com.w3epic.wiprotraining.assignment2;

public class assignment2 {

}
